public class ContaBancaria {
    private double saldo;

    public double getSaldo() {
        return saldo;
    }

    public double sacar(double valor) {
        if(saldo >= valor) {
            saldo -= valor;
        }

        return saldo;
    }

    public double depositar(double valor) {
        if(valor >= 0) {
            saldo += valor;
        }

        return saldo;
    }

    @Override
    public String toString() {
        return "Saldo total: R$ " + saldo;
    }
}
