import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int option = 0;

        Cliente cliente = null;
        ContaBancaria conta = null;

        System.out.println("---------------- BEM VINDO! ----------------");
        while(true) {
            System.out.println("1. Cadastrar.");
            System.out.println("2. Sacar.");
            System.out.println("3. Depositar.");
            System.out.println("4. Extrato.");
            System.out.println("5. Alterar Informações Cadastrais.");
            System.out.println("6. Sair.");

            System.out.print("Digite a opção: ");
            option = sc.nextInt();
            sc.nextLine();

            switch (option) {
                case 1:
                    System.out.println("Cadastrando...");
                    System.out.print("Nome: ");
                    String nome = sc.nextLine();
                    System.out.print("CPF: ");
                    String cpf = sc.nextLine();
                    System.out.print("Telefone: ");
                    String tel = sc.nextLine();
                    System.out.print("Ano de Nascimento: ");
                    int ano = sc.nextInt();
                    System.out.print("Renda Mensal em R$: ");
                    double renda = sc.nextDouble();

                    cliente = new Cliente(nome, cpf, tel, ano, renda);
                    conta = new ContaBancaria();
                    break;
                case 2:
                    System.out.println("Sacando...");
                    System.out.print("Qual valor deseja sacar? R$ ");
                    double valor = sc.nextDouble();

                    if(conta != null) {
                        System.out.println("Saldo atual: " + conta.sacar(valor));
                    }

                    break;
                case 3:
                    System.out.println("Depositando...");
                    System.out.print("Qual valor deseja depositar? R$ ");
                    valor = sc.nextDouble();

                    if(conta != null) {
                        System.out.println("Saldo atual: " + conta.depositar(valor));
                    }

                    break;
                case 4:
                    System.out.println("Imprimindo Extrato...");
                    System.out.println(cliente);
                    System.out.println(conta);
                    break;
                case 5:
                    System.out.println("Alterando infos...");
                    System.out.println("Qual informação deseja alterar?");
                    System.out.println("1. Telefone");
                    System.out.println("2. Renda Mensal");

                    option = sc.nextInt();
                    sc.nextLine();
                    if(option == 1) {
                        System.out.print("Digite o novo telefone: ");
                        cliente.setTelefone(sc.nextLine());
                        System.out.println("Telefone alterado com sucesso!");
                    } else if (option == 2) {
                        System.out.print("Digite a nova renda: R$ ");
                        cliente.setRendaMensal(sc.nextDouble());
                        System.out.println("Renda alterada com sucesso!");

                    }
                    break;
                case 6:
                    System.out.println("Obrigada por utilizar nosso sistema!");
                    return;
                default:
                    System.out.println("Opção Inválida! Digite uma opção válida.");
            }
        }
    }
}