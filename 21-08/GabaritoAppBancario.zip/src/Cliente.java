public class Cliente {
    private String nome;
    private String cpf;
    private String telefone;
    private int anoNascimento;
    private double rendaMensal;

    public Cliente(String nome, String cpf, String telefone, int anoNascimento, double rendaMensal) {
        setNome(nome);
        setCpf(cpf);
        this.telefone = telefone;
        setAnoNascimento(anoNascimento);
        setRendaMensal(rendaMensal);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome.toUpperCase();
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf.replaceAll("(\\d{3})(\\d{3})(\\d{3})(\\d{2})", "$1.$2.$3-$4");
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public int getAnoNascimento() {
        return anoNascimento;
    }

    public void setAnoNascimento(int anoNascimento) {
        if(anoNascimento <= 1900 || anoNascimento > 2024) {
            System.out.println("Ano de nascimento inválido!");
            return;
        }
        this.anoNascimento = anoNascimento;
    }

    public double getRendaMensal() {
        return rendaMensal;
    }

    public void setRendaMensal(double rendaMensal) {
        if(rendaMensal <= 0) {
            System.out.println("Renda mensal inválida!");
            return;
        }
        this.rendaMensal = rendaMensal;
    }

    @Override
    public String toString() {
        return  "Nome: " + nome + "\n" +
                "CPF: " + cpf + "\n" +
                "Telefone: " + telefone + "\n" +
                "Ano de Nascimento: " + anoNascimento + "\n" +
                "Renda Mensal: R$ " + rendaMensal;
    }
}
